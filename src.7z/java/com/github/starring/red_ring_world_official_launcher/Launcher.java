package com.github.starring.red_ring_world_official_launcher;

import javafx.scene.image.Image;

import java.util.Calendar;
import java.util.Random;

import static org.jackhuang.hmcl.ui.FXUtils.newImage;

public class Launcher {
    public static final String NAME = "Red Ring World官方启动器";
    public static final String FULL_NAME = "Red Ring World官方启动器";
    public static final String VERSION = "1.0";
    public static final String TITLE = NAME + " " + VERSION;
    public static String fullName = FULL_NAME + " v" + VERSION + " | ";

    public static void getRandomWord()
    {
        fullName = FULL_NAME + " v" + VERSION + " | ";
        Random random = new Random();
        int number = random.nextInt(9);
        if(number == 0) // 今朝有酒今朝醉,明日愁来明日愁
        {
            fullName += "今朝有酒今朝醉,明日愁来明日愁";
        }
        else if(number == 1) // 众里寻他千百度,蓦然回首,那人却在,灯火阑珊处!
        {
            fullName +=  "众里寻他千百度,蓦然回首,那人却在,灯火阑珊处!";
        }
        else if(number == 2) // 祝每一个二次元人活的开心!
        {
            fullName +=  "祝每一个二次元人活的开心!";
        }
        else if(number == 3) // 总会有地上的生灵,敢于直面雷霆的威光
        {
            fullName +=  "总会有地上的生灵,敢于直面雷霆的威光";
        }
        else if(number == 4) // 早上好~ 初次见面
        {
            Calendar calendar = Calendar.getInstance();
            int time = calendar.get(Calendar.HOUR_OF_DAY);
            if(time >= 5 && time < 11) // 早上
            {
                fullName +=  "早上好~ ";
            }
            else if(time >= 11 && time < 13) // 中文
            {
                fullName +=  "中午好~ ";
            }
            else if(time >= 13 && time < 19) // 下午
            {
                fullName +=  "下午好~ ";
            }
            else if(time >= 19 && time < 24) // 晚上
            {
                fullName +=  "晚上好~ ";
            }
            else if(time >= 0 && time < 5) // 凌晨
            {
                fullName +=  "凌晨好~ ";
            }
        }
        else if(number == 5) // 若你被困于无风之地,我便为你奏响高天之歌
        {
            fullName +=  "若你被困于无风之地,我便为你奏响高天之歌";
        }
        else if(number == 6) // 给岁月以文明,而不是给文明以岁月
        {
            fullName +=  "给岁月以文明,而不是给文明以岁月";
        }
        else if(number == 7) // 自然选择,前进四!
        {
            fullName +=  "自然选择,前进四!";
        }
        else if(number == 8) // 我本知生命如朝露般短暂,然而他又像朝阳般绚丽多彩,黑夜总会降临,白昼终会到来,生命也是如此
        {
            fullName +=  "我本知生命如朝露般短暂,然而他又像朝阳般绚丽多彩,黑夜总会降临,白昼终会到来,生命也是如此";
        }
    }

    public static Image getRandomBackground()
    {
        Image image;
        String path = "/assets/img/background/";
        String back_name = ".jpg";
        Random r = new Random();
        int number = r.nextInt(4);
        if(number == 0) // Hu Tao
        {
            path += "HuTao/";
            number = r.nextInt(7);
        }
        else if(number == 1) // Kamisato Ayaka
        {
            path += "KamisatoAyaka/";
            number = r.nextInt(3);
        }
        else if(number == 2) // Other
        {
            path += "Other/";
            number = r.nextInt(26);
        }
        else if(number == 3) // Nahida
        {
            path += "Nahida/";
            number = r.nextInt(2);
        }
        image = newImage(path + number + back_name);
        return image;
    }
}
