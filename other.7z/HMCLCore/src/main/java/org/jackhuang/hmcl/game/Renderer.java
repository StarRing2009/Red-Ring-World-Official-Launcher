package org.jackhuang.hmcl.game;

public enum Renderer {
    DEFAULT,
    ZINK,
    LLVMPIPE,
    D3D12
}
